import os
import threading
import pygame
import sqlite3
import time
import random
from ffmpy import FFmpeg
import subprocess
import dialogue_manager
import sys
import importlib


from tkinter import *

# Use this function to play movies.
# 'mpath' is the url of the movie to play

def playSilence():
    list1 = ["22.mov", "11.mov", "12.mov", "13.mov", "14.mov", "15.mov"]
    chosen_video = random.choice(list1)
    print("building loop")
    clip6 = VideoFileClip(random.choice(list1))
    #clip6.preview()
    clip1 = VideoFileClip(random.choice(list1))
    #clip1.preview()
    clip2 = VideoFileClip(random.choice(list1))
    #clip2.preview()
    clip3 = VideoFileClip(random.choice(list1))
    #clip3.preview()
    clip4 = VideoFileClip(random.choice(list1))
    #clip4.preview()
    clip5 = VideoFileClip(random.choice(list1))
    #clip5.preview()
    video = concatenate_videoclips([clip6, clip2, clip3, clip4, clip5])
    #video.write_videofile("loop.mp4", codec='libx264')
    #loop_clip = VideoFileClip("loop.mp4")
    #loop_clip.preview()

#@requires_duration
#@convert_masks_to_RGB
#def preview(clip, fps=15, audio=True, audio_fps=22050,
#            audio_buffersize=3000, audio_nbytes=2):
#    """
#        Displays the clip in a window, at the given frames per second
#        (of movie) rate. It will avoid that the clip be played faster
#        than normal, but it cannot avoid the clip to be played slower
#        than normal if the computations are complex. In this case, try
#        reducing the ``fps``.
#
#        Parameters
#        ------------
#
#        fps
#        Number of frames per seconds in the displayed video.
#
#        audio
#        ``True`` (default) if you want the clip's audio be played during
#        the preview.
#
#        audiofps
#        The frames per second to use when generating the audio sound.
#
#        """
#
#    import pygame as pg
#
#    # compute and splash the first image
#    screen = pg.display.set_mode(clip.size)
#
#    audio = audio and (clip.audio is not None)
#
#    if audio:
#        # the sound will be played in parrallel. We are not
#        # parralellizing it on different CPUs because it seems that
#        # pygame and openCV already use several cpus it seems.
#
#        # two synchro-flags to tell whether audio and video are ready
#        videoFlag = threading.Event()
#        audioFlag = threading.Event()
#        # launch the thread
#        audiothread = threading.Thread(target=clip.audio.preview,
#                                       args = (audio_fps,audio_buffersize, audio_nbytes,
#                                               audioFlag, videoFlag))
#        audiothread.start()
#
#    img = clip.get_frame(0)
#    imdisplay(img, screen)
#    if audio: # synchronize with audio
#        videoFlag.set() # say to the audio: video is ready
#        audioFlag.wait() # wait for the audio to be ready
#
#    result = []
#
#    t0 = time.time()
#    for t in np.arange(1.0 / fps, clip.duration-.001, 1.0 / fps):
#
#        img = clip.get_frame(t)
#
#        for event in pg.event.get():
#            if event.type == pg.KEYDOWN:
#                if (event.key == pg.K_ESCAPE):
#
#                    if audio:
#                        videoFlag.clear()
#                    print( "Keyboard interrupt" )
#                    return result
#
#            elif event.type == pg.MOUSEBUTTONDOWN:
#                x,y = pg.mouse.get_pos()
#                rgb = img[y,x]
#                result.append({'time':t, 'position':(x,y),
#                              'color':rgb})
#                print( "time, position, color : ", "%.03f, %s, %s"%(t,str((x,y)),str(rgb)))
#
#        t1 = time.time()
#        time.sleep(max(0, t - (t1-t0)) )
#        imdisplay(img, screen)

def playMovie(mpath, caption):
    clip = VideoFileClip(mpath)
    new_mpath = mpath
    #generator = lambda txt: TextClip(txt, font='Georgia-Regular', fontsize=20, color='white')
    #movie_duration = FFmpeg(inputs={mpath: "2>&1 | grep 'Duration'| cut -d ' ' -f 4 | sed s/,// | sed 's@\..*@@g' | awk '{ split($1, A, ':'); split(A[3], B, '.'); print 3600*A[1] + 60*A[2] + B[1] }'"}, outputs={"Duration" : None})
    #movie_duration.run()
    text_clip = TextClip(caption, fontsize=20, color='white')
    text_clip = text_clip.set_pos('bottom').set_duration(4)
    ff = FFmpeg(inputs={mpath: "-f mp3 -ab 192000 -vn"}, outputs={"output.mp3" : None})
    #text_clip = SubtitlesClip(caption, generator)
    video = CompositeVideoClip([clip, text_clip], use_bgclip=False)
    video.write_videofile(new_mpath, codec="png")
    new_video = VideoFileClip(new_mpath)
    new_video.preview()
    response_text.delete(1.0, END)


def select_product(id):
    with sqlite3.connect("questions.db") as db:
        cursor = db.cursor()
        cursor.execute("select AnswerID from Questions where QuestionID=?", (id,))
        product = cursor.fetchone()
        return product

def array_questions():
    with sqlite3.connect("questions.db") as db:
        cursor = db.cursor()
        cursor.execute("select Prompt from Questions")
        rows = cursor.fetchall()
        all_questions = []
        print(rows)
        for i in rows:
            # for j in i:
            #     ' '.join(j)
            #     all_questions.append(j)
            converted_q = " ".join(i)
            print(converted_q)
            all_questions.append(converted_q)
        #print(all_questions)
        return all_questions
        
def select_answer(other_id):
    with sqlite3.connect("answers.db") as db:
        cursor = db.cursor()
        cursor.execute("select Answer from Answers where AnswerID=?", other_id)
        product = cursor.fetchone()
        return product

def select_text(text_id):
    with sqlite3.connect("answers.db") as db:
        cursor = db.cursor()
        cursor.execute("select Translation from Answers where AnswerID=?", text_id)
        product = cursor.fetchone()
        return product

def get_response():
    contents = response_text.get(1.0, END)
    question_matching = array_questions()
    dialogue_manager.main(contents, question_matching)
    #request = select_product("get questions from dialogue manager")
    #answer = select_answer(request)
    #caption = select_text(request)
    #playMovie(''.join(answer), ''.join(caption))
    print("Hopefully I return a movie number next time.")


if __name__ == '__main__':

    #input = importlib.import_module('dialogue_manager.py')
    # Setup root window UI
    root = Tk()
    root.title('Root Window')

    response_text = Text(root)
    response_text.config(bd=2, height=10, relief=RAISED)

    welcome_label = Label(root, text="Welcome to TOIA")
    response_label = Label(root, text="Please ask your question below: ")
    start_button = Button(root, text="Start", command=playSilence)
    submit_button = Button(root, text="Submit", command=get_response)

    welcome_label.grid(row=0, column=0)
    response_label.grid(row=4, column=1)
    response_text.grid(row=5, column=1)
    submit_button.grid(row=6, column=1)
    start_button.grid(row=7, column=2)

    #========================== Don't touch this!!! ==========================#
    # Width and height of movie window.
    # The values don't really matter since movie py will change them anyway
    w = 50
    h = 50

    embed = Frame(root, width=w, height=h)
    embed.grid(row=1, column=1)

    # We have to tell SDL which window to draw to
    os.environ['SDL_WINDOWID'] = str(embed.winfo_id())

    # The wxPython wiki says you might need the following line on Windows
    # (http://wiki.wxpython.org/IntegratingPyGame).
    # os.environ['SDL_VIDEODRIVER'] = 'windib'

    root.update()

    pygame.display.init()
    screen = pygame.display.set_mode((w, h))

    # Now we can import moviepy without any errors
    from moviepy.editor import *
    from moviepy.video.tools.subtitles import SubtitlesClip
    #=========================================================================#

    # Set the title of the video window here
    pygame.display.set_caption('Movie Window')

    # Note: All moviepy code should come below

    # This is a substitute for root.mainloop()
    # Here you can listen to events and call playMovie accordingly
    #time.sleep(1)
    #playSilence()
    while True:
        
        for event in pygame.event.get():
            if event.type == pygame.K_ESCAPE:
                playSilence.exit()

#        if response_text.get(1.0, END) == '':
#            playSilence()


        # Put your business logic here before root is updated

        root.update_idletasks()
        root.update()


